Solution.java is the initial code they had given
It was a function problem
main was in stubber code
we had to only change function
